generated-files: $(wildcard keyboards/ymkn/slab40/info.json)

generated-files: $(wildcard keyboards/ymkn/slab40/keyboard.json)

generated-files: $(wildcard keyboards/ymkn/slab40/rules.mk)

generated-files: $(wildcard keyboards/ymkn/slab40/post_rules.mk)

generated-files: $(wildcard keyboards/ymkn/slab40/config.h)

generated-files: $(wildcard keyboards/ymkn/slab40/post_config.h)

generated-files: $(wildcard keyboards/ymkn/info.json)

generated-files: $(wildcard keyboards/ymkn/keyboard.json)

generated-files: $(wildcard keyboards/ymkn/rules.mk)

generated-files: $(wildcard keyboards/ymkn/post_rules.mk)

generated-files: $(wildcard keyboards/ymkn/config.h)

generated-files: $(wildcard keyboards/ymkn/post_config.h)

generated-files: $(wildcard /qmk_firmware/keyboards/ymkn/slab40/keymaps/vial/keymap.json)

generated-files: $(wildcard /qmk_firmware/keyboards/ymkn/slab40/keymaps/vial/info.json)

generated-files: $(wildcard /qmk_firmware/keyboards/ymkn/slab40/keymaps/vial/keyboard.json)

generated-files: $(wildcard /qmk_firmware/keyboards/ymkn/slab40/keymaps/vial/rules.mk)

generated-files: $(wildcard /qmk_firmware/keyboards/ymkn/slab40/keymaps/vial/post_rules.mk)

generated-files: $(wildcard /qmk_firmware/keyboards/ymkn/slab40/keymaps/vial/config.h)

generated-files: $(wildcard /qmk_firmware/keyboards/ymkn/slab40/keymaps/vial/post_config.h)

generated-files: $(wildcard users/vial/info.json)

generated-files: $(wildcard users/vial/keyboard.json)

generated-files: $(wildcard users/vial/rules.mk)

generated-files: $(wildcard users/vial/post_rules.mk)

generated-files: $(wildcard users/vial/config.h)

generated-files: $(wildcard users/vial/post_config.h)

