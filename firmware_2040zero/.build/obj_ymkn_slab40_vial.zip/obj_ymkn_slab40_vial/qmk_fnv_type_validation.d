.build/obj_ymkn_slab40_vial/qmk_fnv_type_validation.o: \
 lib/fnv/qmk_fnv_type_validation.c keyboards/ymkn/slab40/config.h \
 .build/obj_ymkn_slab40_vial/src/info_config.h \
 keyboards/ymkn/slab40/keymaps/vial/config.h platforms/chibios/config.h \
 lib/fnv/fnv.h lib/fnv/longlong.h quantum/compiler_support.h

keyboards/ymkn/slab40/config.h:

.build/obj_ymkn_slab40_vial/src/info_config.h:

keyboards/ymkn/slab40/keymaps/vial/config.h:

platforms/chibios/config.h:

lib/fnv/fnv.h:

lib/fnv/longlong.h:

quantum/compiler_support.h:
