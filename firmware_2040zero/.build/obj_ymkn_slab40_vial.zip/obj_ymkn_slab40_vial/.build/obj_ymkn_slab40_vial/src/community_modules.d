.build/obj_ymkn_slab40_vial/.build/obj_ymkn_slab40_vial/src/community_modules.o: \
 .build/obj_ymkn_slab40_vial/src/community_modules.c \
 keyboards/ymkn/slab40/config.h \
 .build/obj_ymkn_slab40_vial/src/info_config.h \
 keyboards/ymkn/slab40/keymaps/vial/config.h platforms/chibios/config.h \
 .build/obj_ymkn_slab40_vial/src/community_modules.h quantum/keycodes.h \
 quantum/compiler_support.h

keyboards/ymkn/slab40/config.h:

.build/obj_ymkn_slab40_vial/src/info_config.h:

keyboards/ymkn/slab40/keymaps/vial/config.h:

platforms/chibios/config.h:

.build/obj_ymkn_slab40_vial/src/community_modules.h:

quantum/keycodes.h:

quantum/compiler_support.h:
