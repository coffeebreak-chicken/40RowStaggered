.build/obj_ymkn_slab40_vial/./lib/pico-sdk/src/rp2_common/hardware_clocks/clocks.o: \
 lib/pico-sdk/src/rp2_common/hardware_clocks/clocks.c \
 keyboards/ymkn/slab40/config.h \
 .build/obj_ymkn_slab40_vial/src/info_config.h \
 keyboards/ymkn/slab40/keymaps/vial/config.h platforms/chibios/config.h \
 lib/pico-sdk/src/common/pico_base/include/pico.h \
 lib/pico-sdk/src/common/pico_base/include/pico/types.h \
 lib/pico-sdk/src/common/pico_base/include/pico/assert.h \
 lib/chibios//os/various/pico_bindings/dumb/include/pico/version.h \
 lib/pico-sdk/src/common/pico_base/include/pico/config.h \
 lib/chibios//os/various/pico_bindings/dumb/include/pico/config_autogen.h \
 lib/pico-sdk/src/boards/include/boards/pico.h \
 lib/pico-sdk/src/rp2_common/pico_platform/include/pico/platform.h \
 lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/platform_defs.h \
 lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/addressmap.h \
 lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/sio.h \
 lib/pico-sdk/src/common/pico_base/include/pico/types.h \
 lib/pico-sdk/src/common/pico_base/include/pico/error.h \
 lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/clocks.h \
 lib/pico-sdk/src/rp2_common/hardware_clocks/include/hardware/clocks.h \
 lib/pico-sdk/src/rp2040/hardware_structs/include/hardware/structs/clocks.h \
 lib/pico-sdk/src/rp2_common/hardware_base/include/hardware/address_mapped.h \
 lib/pico-sdk/src/rp2_common/hardware_watchdog/include/hardware/watchdog.h \
 lib/pico-sdk/src/rp2040/hardware_structs/include/hardware/structs/watchdog.h \
 lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/watchdog.h \
 lib/pico-sdk/src/rp2_common/hardware_pll/include/hardware/pll.h \
 lib/pico-sdk/src/rp2040/hardware_structs/include/hardware/structs/pll.h \
 lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/pll.h \
 lib/pico-sdk/src/rp2_common/hardware_xosc/include/hardware/xosc.h \
 lib/pico-sdk/src/rp2040/hardware_structs/include/hardware/structs/xosc.h \
 lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/xosc.h \
 lib/pico-sdk/src/rp2_common/hardware_irq/include/hardware/irq.h \
 lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/intctrl.h \
 lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/m0plus.h \
 lib/pico-sdk/src/rp2_common/hardware_gpio/include/hardware/gpio.h \
 lib/pico-sdk/src/rp2040/hardware_structs/include/hardware/structs/sio.h \
 lib/pico-sdk/src/rp2040/hardware_structs/include/hardware/structs/interp.h \
 lib/pico-sdk/src/rp2040/hardware_structs/include/hardware/structs/padsbank0.h \
 lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/pads_bank0.h \
 lib/pico-sdk/src/rp2040/hardware_structs/include/hardware/structs/iobank0.h \
 lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/io_bank0.h

keyboards/ymkn/slab40/config.h:

.build/obj_ymkn_slab40_vial/src/info_config.h:

keyboards/ymkn/slab40/keymaps/vial/config.h:

platforms/chibios/config.h:

lib/pico-sdk/src/common/pico_base/include/pico.h:

lib/pico-sdk/src/common/pico_base/include/pico/types.h:

lib/pico-sdk/src/common/pico_base/include/pico/assert.h:

lib/chibios//os/various/pico_bindings/dumb/include/pico/version.h:

lib/pico-sdk/src/common/pico_base/include/pico/config.h:

lib/chibios//os/various/pico_bindings/dumb/include/pico/config_autogen.h:

lib/pico-sdk/src/boards/include/boards/pico.h:

lib/pico-sdk/src/rp2_common/pico_platform/include/pico/platform.h:

lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/platform_defs.h:

lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/addressmap.h:

lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/sio.h:

lib/pico-sdk/src/common/pico_base/include/pico/types.h:

lib/pico-sdk/src/common/pico_base/include/pico/error.h:

lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/clocks.h:

lib/pico-sdk/src/rp2_common/hardware_clocks/include/hardware/clocks.h:

lib/pico-sdk/src/rp2040/hardware_structs/include/hardware/structs/clocks.h:

lib/pico-sdk/src/rp2_common/hardware_base/include/hardware/address_mapped.h:

lib/pico-sdk/src/rp2_common/hardware_watchdog/include/hardware/watchdog.h:

lib/pico-sdk/src/rp2040/hardware_structs/include/hardware/structs/watchdog.h:

lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/watchdog.h:

lib/pico-sdk/src/rp2_common/hardware_pll/include/hardware/pll.h:

lib/pico-sdk/src/rp2040/hardware_structs/include/hardware/structs/pll.h:

lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/pll.h:

lib/pico-sdk/src/rp2_common/hardware_xosc/include/hardware/xosc.h:

lib/pico-sdk/src/rp2040/hardware_structs/include/hardware/structs/xosc.h:

lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/xosc.h:

lib/pico-sdk/src/rp2_common/hardware_irq/include/hardware/irq.h:

lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/intctrl.h:

lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/m0plus.h:

lib/pico-sdk/src/rp2_common/hardware_gpio/include/hardware/gpio.h:

lib/pico-sdk/src/rp2040/hardware_structs/include/hardware/structs/sio.h:

lib/pico-sdk/src/rp2040/hardware_structs/include/hardware/structs/interp.h:

lib/pico-sdk/src/rp2040/hardware_structs/include/hardware/structs/padsbank0.h:

lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/pads_bank0.h:

lib/pico-sdk/src/rp2040/hardware_structs/include/hardware/structs/iobank0.h:

lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/io_bank0.h:
