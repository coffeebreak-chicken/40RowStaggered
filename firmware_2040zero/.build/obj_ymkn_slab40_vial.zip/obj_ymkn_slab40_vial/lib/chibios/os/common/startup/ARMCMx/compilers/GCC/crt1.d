.build/obj_ymkn_slab40_vial/lib/chibios/os/common/startup/ARMCMx/compilers/GCC/crt1.o: \
 lib/chibios/os/common/startup/ARMCMx/compilers/GCC/crt1.c \
 keyboards/ymkn/slab40/config.h \
 .build/obj_ymkn_slab40_vial/src/info_config.h \
 keyboards/ymkn/slab40/keymaps/vial/config.h platforms/chibios/config.h \
 lib/chibios/os/common/startup/ARMCMx/devices/RP2040/cmparams.h \
 platforms/chibios/boards/GENERIC_RP_RP2040/configs/board.h \
 lib/chibios/os/hal/boards/RP_PICO_RP2040/board.h \
 lib/chibios/os/common/ext/RP/RP2040/rp2040.h \
 lib/chibios/os/common/ext/ARM/CMSIS/Core/Include/core_cm0plus.h \
 lib/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_version.h \
 lib/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_compiler.h \
 lib/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_gcc.h \
 lib/chibios/os/common/ext/ARM/CMSIS/Core/Include/mpu_armv7.h \
 lib/chibios/os/common/ext/RP/RP2040/system_rp2040.h

keyboards/ymkn/slab40/config.h:

.build/obj_ymkn_slab40_vial/src/info_config.h:

keyboards/ymkn/slab40/keymaps/vial/config.h:

platforms/chibios/config.h:

lib/chibios/os/common/startup/ARMCMx/devices/RP2040/cmparams.h:

platforms/chibios/boards/GENERIC_RP_RP2040/configs/board.h:

lib/chibios/os/hal/boards/RP_PICO_RP2040/board.h:

lib/chibios/os/common/ext/RP/RP2040/rp2040.h:

lib/chibios/os/common/ext/ARM/CMSIS/Core/Include/core_cm0plus.h:

lib/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_version.h:

lib/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_compiler.h:

lib/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_gcc.h:

lib/chibios/os/common/ext/ARM/CMSIS/Core/Include/mpu_armv7.h:

lib/chibios/os/common/ext/RP/RP2040/system_rp2040.h:
