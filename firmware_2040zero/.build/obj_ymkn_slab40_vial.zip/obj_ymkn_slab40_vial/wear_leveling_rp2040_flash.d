.build/obj_ymkn_slab40_vial/wear_leveling_rp2040_flash.o: \
 platforms/chibios/drivers/wear_leveling/wear_leveling_rp2040_flash.c \
 keyboards/ymkn/slab40/config.h \
 .build/obj_ymkn_slab40_vial/src/info_config.h \
 keyboards/ymkn/slab40/keymaps/vial/config.h platforms/chibios/config.h \
 lib/pico-sdk/src/rp2_common/pico_bootrom/include/pico/bootrom.h \
 lib/pico-sdk/src/common/pico_base/include/pico.h \
 lib/pico-sdk/src/common/pico_base/include/pico/types.h \
 lib/pico-sdk/src/common/pico_base/include/pico/assert.h \
 lib/chibios//os/various/pico_bindings/dumb/include/pico/version.h \
 lib/pico-sdk/src/common/pico_base/include/pico/config.h \
 lib/chibios//os/various/pico_bindings/dumb/include/pico/config_autogen.h \
 lib/pico-sdk/src/boards/include/boards/pico.h \
 lib/pico-sdk/src/rp2_common/pico_platform/include/pico/platform.h \
 lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/platform_defs.h \
 lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/addressmap.h \
 lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/sio.h \
 lib/pico-sdk/src/common/pico_base/include/pico/types.h \
 lib/pico-sdk/src/common/pico_base/include/pico/error.h \
 lib/pico-sdk/src/rp2_common/hardware_flash/include/hardware/flash.h \
 lib/pico-sdk/src/rp2_common/hardware_sync/include/hardware/sync.h \
 lib/pico-sdk/src/rp2_common/hardware_base/include/hardware/address_mapped.h \
 lib/pico-sdk/src/rp2040/hardware_structs/include/hardware/structs/ssi.h \
 lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/ssi.h \
 lib/pico-sdk/src/rp2040/hardware_structs/include/hardware/structs/ioqspi.h \
 lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/io_qspi.h \
 quantum/compiler_support.h platforms/timer.h platforms/chibios/_timer.h \
 quantum/wear_leveling/wear_leveling.h \
 platforms/chibios/drivers/wear_leveling/wear_leveling_rp2040_flash_config.h \
 quantum/wear_leveling/wear_leveling_internal.h

keyboards/ymkn/slab40/config.h:

.build/obj_ymkn_slab40_vial/src/info_config.h:

keyboards/ymkn/slab40/keymaps/vial/config.h:

platforms/chibios/config.h:

lib/pico-sdk/src/rp2_common/pico_bootrom/include/pico/bootrom.h:

lib/pico-sdk/src/common/pico_base/include/pico.h:

lib/pico-sdk/src/common/pico_base/include/pico/types.h:

lib/pico-sdk/src/common/pico_base/include/pico/assert.h:

lib/chibios//os/various/pico_bindings/dumb/include/pico/version.h:

lib/pico-sdk/src/common/pico_base/include/pico/config.h:

lib/chibios//os/various/pico_bindings/dumb/include/pico/config_autogen.h:

lib/pico-sdk/src/boards/include/boards/pico.h:

lib/pico-sdk/src/rp2_common/pico_platform/include/pico/platform.h:

lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/platform_defs.h:

lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/addressmap.h:

lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/sio.h:

lib/pico-sdk/src/common/pico_base/include/pico/types.h:

lib/pico-sdk/src/common/pico_base/include/pico/error.h:

lib/pico-sdk/src/rp2_common/hardware_flash/include/hardware/flash.h:

lib/pico-sdk/src/rp2_common/hardware_sync/include/hardware/sync.h:

lib/pico-sdk/src/rp2_common/hardware_base/include/hardware/address_mapped.h:

lib/pico-sdk/src/rp2040/hardware_structs/include/hardware/structs/ssi.h:

lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/ssi.h:

lib/pico-sdk/src/rp2040/hardware_structs/include/hardware/structs/ioqspi.h:

lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/io_qspi.h:

quantum/compiler_support.h:

platforms/timer.h:

platforms/chibios/_timer.h:

quantum/wear_leveling/wear_leveling.h:

platforms/chibios/drivers/wear_leveling/wear_leveling_rp2040_flash_config.h:

quantum/wear_leveling/wear_leveling_internal.h:
