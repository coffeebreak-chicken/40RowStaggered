.build/obj_ymkn_slab40_vial/quantum/layer_lock.o: quantum/layer_lock.c \
 keyboards/ymkn/slab40/config.h \
 .build/obj_ymkn_slab40_vial/src/info_config.h \
 keyboards/ymkn/slab40/keymaps/vial/config.h platforms/chibios/config.h \
 quantum/layer_lock.h quantum/action_layer.h quantum/keyboard.h \
 platforms/timer.h platforms/chibios/_timer.h quantum/action.h \
 platforms/progmem.h quantum/keycode.h quantum/keycodes.h \
 quantum/modifiers.h quantum/action_code.h quantum/bitwise.h \
 quantum/action_util.h tmk_core/protocol/report.h quantum/util.h \
 quantum/bits.h platforms/chibios/_util.h quantum/quantum_keycodes.h \
 quantum/keymap_extras/keymap_us.h quantum/sequencer/sequencer.h \
 quantum/quantum_keycodes_legacy.h

keyboards/ymkn/slab40/config.h:

.build/obj_ymkn_slab40_vial/src/info_config.h:

keyboards/ymkn/slab40/keymaps/vial/config.h:

platforms/chibios/config.h:

quantum/layer_lock.h:

quantum/action_layer.h:

quantum/keyboard.h:

platforms/timer.h:

platforms/chibios/_timer.h:

quantum/action.h:

platforms/progmem.h:

quantum/keycode.h:

quantum/keycodes.h:

quantum/modifiers.h:

quantum/action_code.h:

quantum/bitwise.h:

quantum/action_util.h:

tmk_core/protocol/report.h:

quantum/util.h:

quantum/bits.h:

platforms/chibios/_util.h:

quantum/quantum_keycodes.h:

quantum/keymap_extras/keymap_us.h:

quantum/sequencer/sequencer.h:

quantum/quantum_keycodes_legacy.h:
