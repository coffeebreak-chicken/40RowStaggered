.build/obj_ymkn_slab40_vial/quantum/main.o: quantum/main.c \
 keyboards/ymkn/slab40/config.h \
 .build/obj_ymkn_slab40_vial/src/info_config.h \
 keyboards/ymkn/slab40/keymaps/vial/config.h platforms/chibios/config.h \
 quantum/keyboard.h platforms/timer.h platforms/chibios/_timer.h

keyboards/ymkn/slab40/config.h:

.build/obj_ymkn_slab40_vial/src/info_config.h:

keyboards/ymkn/slab40/keymaps/vial/config.h:

platforms/chibios/config.h:

quantum/keyboard.h:

platforms/timer.h:

platforms/chibios/_timer.h:
