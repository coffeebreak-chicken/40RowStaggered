.build/obj_ymkn_slab40_vial/quantum/keycode_config.o: \
 quantum/keycode_config.c keyboards/ymkn/slab40/config.h \
 .build/obj_ymkn_slab40_vial/src/info_config.h \
 keyboards/ymkn/slab40/keymaps/vial/config.h platforms/chibios/config.h \
 quantum/keycode_config.h quantum/compiler_support.h quantum/eeconfig.h \
 quantum/action_layer.h quantum/keyboard.h platforms/timer.h \
 platforms/chibios/_timer.h quantum/action.h platforms/progmem.h \
 quantum/keycode.h quantum/keycodes.h quantum/modifiers.h \
 quantum/action_code.h quantum/bitwise.h

keyboards/ymkn/slab40/config.h:

.build/obj_ymkn_slab40_vial/src/info_config.h:

keyboards/ymkn/slab40/keymaps/vial/config.h:

platforms/chibios/config.h:

quantum/keycode_config.h:

quantum/compiler_support.h:

quantum/eeconfig.h:

quantum/action_layer.h:

quantum/keyboard.h:

platforms/timer.h:

platforms/chibios/_timer.h:

quantum/action.h:

platforms/progmem.h:

quantum/keycode.h:

quantum/keycodes.h:

quantum/modifiers.h:

quantum/action_code.h:

quantum/bitwise.h:
