.build/obj_ymkn_slab40_vial/quantum/caps_word.o: quantum/caps_word.c \
 keyboards/ymkn/slab40/config.h \
 .build/obj_ymkn_slab40_vial/src/info_config.h \
 keyboards/ymkn/slab40/keymaps/vial/config.h platforms/chibios/config.h \
 quantum/caps_word.h platforms/timer.h platforms/chibios/_timer.h \
 quantum/action.h platforms/progmem.h quantum/keyboard.h \
 quantum/keycode.h quantum/keycodes.h quantum/modifiers.h \
 quantum/action_code.h quantum/action_util.h tmk_core/protocol/report.h \
 quantum/util.h quantum/bits.h quantum/bitwise.h \
 platforms/chibios/_util.h

keyboards/ymkn/slab40/config.h:

.build/obj_ymkn_slab40_vial/src/info_config.h:

keyboards/ymkn/slab40/keymaps/vial/config.h:

platforms/chibios/config.h:

quantum/caps_word.h:

platforms/timer.h:

platforms/chibios/_timer.h:

quantum/action.h:

platforms/progmem.h:

quantum/keyboard.h:

quantum/keycode.h:

quantum/keycodes.h:

quantum/modifiers.h:

quantum/action_code.h:

quantum/action_util.h:

tmk_core/protocol/report.h:

quantum/util.h:

quantum/bits.h:

quantum/bitwise.h:

platforms/chibios/_util.h:
