.build/obj_ymkn_slab40_vial/quantum/logging/debug.o: \
 quantum/logging/debug.c keyboards/ymkn/slab40/config.h \
 .build/obj_ymkn_slab40_vial/src/info_config.h \
 keyboards/ymkn/slab40/keymaps/vial/config.h platforms/chibios/config.h \
 quantum/logging/debug.h quantum/logging/print.h quantum/util.h \
 quantum/bits.h quantum/bitwise.h platforms/chibios/_util.h \
 quantum/logging/sendchar.h platforms/progmem.h

keyboards/ymkn/slab40/config.h:

.build/obj_ymkn_slab40_vial/src/info_config.h:

keyboards/ymkn/slab40/keymaps/vial/config.h:

platforms/chibios/config.h:

quantum/logging/debug.h:

quantum/logging/print.h:

quantum/util.h:

quantum/bits.h:

quantum/bitwise.h:

platforms/chibios/_util.h:

quantum/logging/sendchar.h:

platforms/progmem.h:
