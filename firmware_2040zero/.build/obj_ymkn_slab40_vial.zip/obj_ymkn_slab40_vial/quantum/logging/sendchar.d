.build/obj_ymkn_slab40_vial/quantum/logging/sendchar.o: \
 quantum/logging/sendchar.c keyboards/ymkn/slab40/config.h \
 .build/obj_ymkn_slab40_vial/src/info_config.h \
 keyboards/ymkn/slab40/keymaps/vial/config.h platforms/chibios/config.h \
 quantum/logging/sendchar.h

keyboards/ymkn/slab40/config.h:

.build/obj_ymkn_slab40_vial/src/info_config.h:

keyboards/ymkn/slab40/keymaps/vial/config.h:

platforms/chibios/config.h:

quantum/logging/sendchar.h:
