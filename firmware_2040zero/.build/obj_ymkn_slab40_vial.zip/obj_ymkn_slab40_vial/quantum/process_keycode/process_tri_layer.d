.build/obj_ymkn_slab40_vial/quantum/process_keycode/process_tri_layer.o: \
 quantum/process_keycode/process_tri_layer.c \
 keyboards/ymkn/slab40/config.h \
 .build/obj_ymkn_slab40_vial/src/info_config.h \
 keyboards/ymkn/slab40/keymaps/vial/config.h platforms/chibios/config.h \
 quantum/process_keycode/process_tri_layer.h quantum/action.h \
 platforms/progmem.h quantum/keyboard.h platforms/timer.h \
 platforms/chibios/_timer.h quantum/keycode.h quantum/keycodes.h \
 quantum/modifiers.h quantum/action_code.h quantum/tri_layer.h \
 quantum/action_layer.h quantum/bitwise.h

keyboards/ymkn/slab40/config.h:

.build/obj_ymkn_slab40_vial/src/info_config.h:

keyboards/ymkn/slab40/keymaps/vial/config.h:

platforms/chibios/config.h:

quantum/process_keycode/process_tri_layer.h:

quantum/action.h:

platforms/progmem.h:

quantum/keyboard.h:

platforms/timer.h:

platforms/chibios/_timer.h:

quantum/keycode.h:

quantum/keycodes.h:

quantum/modifiers.h:

quantum/action_code.h:

quantum/tri_layer.h:

quantum/action_layer.h:

quantum/bitwise.h:
