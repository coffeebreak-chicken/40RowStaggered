.build/obj_ymkn_slab40_vial/quantum/eeconfig.o: quantum/eeconfig.c \
 keyboards/ymkn/slab40/config.h \
 .build/obj_ymkn_slab40_vial/src/info_config.h \
 keyboards/ymkn/slab40/keymaps/vial/config.h platforms/chibios/config.h \
 quantum/logging/debug.h quantum/logging/print.h quantum/util.h \
 quantum/bits.h quantum/bitwise.h platforms/chibios/_util.h \
 quantum/logging/sendchar.h platforms/progmem.h quantum/eeconfig.h \
 quantum/action_layer.h quantum/keyboard.h platforms/timer.h \
 platforms/chibios/_timer.h quantum/action.h quantum/keycode.h \
 quantum/keycodes.h quantum/modifiers.h quantum/action_code.h \
 quantum/nvm/nvm_eeconfig.h quantum/keycode_config.h \
 quantum/compiler_support.h

keyboards/ymkn/slab40/config.h:

.build/obj_ymkn_slab40_vial/src/info_config.h:

keyboards/ymkn/slab40/keymaps/vial/config.h:

platforms/chibios/config.h:

quantum/logging/debug.h:

quantum/logging/print.h:

quantum/util.h:

quantum/bits.h:

quantum/bitwise.h:

platforms/chibios/_util.h:

quantum/logging/sendchar.h:

platforms/progmem.h:

quantum/eeconfig.h:

quantum/action_layer.h:

quantum/keyboard.h:

platforms/timer.h:

platforms/chibios/_timer.h:

quantum/action.h:

quantum/keycode.h:

quantum/keycodes.h:

quantum/modifiers.h:

quantum/action_code.h:

quantum/nvm/nvm_eeconfig.h:

quantum/keycode_config.h:

quantum/compiler_support.h:
