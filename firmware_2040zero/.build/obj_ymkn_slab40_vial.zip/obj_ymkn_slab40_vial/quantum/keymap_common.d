.build/obj_ymkn_slab40_vial/quantum/keymap_common.o: \
 quantum/keymap_common.c keyboards/ymkn/slab40/config.h \
 .build/obj_ymkn_slab40_vial/src/info_config.h \
 keyboards/ymkn/slab40/keymaps/vial/config.h platforms/chibios/config.h \
 quantum/keymap_common.h quantum/keyboard.h platforms/timer.h \
 platforms/chibios/_timer.h quantum/keymap_introspection.h \
 tmk_core/protocol/report.h quantum/keycode.h quantum/keycodes.h \
 quantum/modifiers.h quantum/util.h quantum/bits.h quantum/bitwise.h \
 platforms/chibios/_util.h quantum/action_layer.h quantum/action.h \
 platforms/progmem.h quantum/action_code.h quantum/logging/debug.h \
 quantum/logging/print.h quantum/logging/sendchar.h \
 quantum/keycode_config.h quantum/compiler_support.h quantum/eeconfig.h \
 quantum/quantum_keycodes.h quantum/keymap_extras/keymap_us.h \
 quantum/sequencer/sequencer.h quantum/quantum_keycodes_legacy.h \
 quantum/vial.h platforms/eeprom.h \
 quantum/wear_leveling/wear_leveling_drivers.h \
 platforms/chibios/drivers/wear_leveling/wear_leveling_rp2040_flash_config.h \
 lib/pico-sdk/src/rp2_common/hardware_flash/include/hardware/flash.h \
 lib/pico-sdk/src/common/pico_base/include/pico.h \
 lib/pico-sdk/src/common/pico_base/include/pico/types.h \
 lib/pico-sdk/src/common/pico_base/include/pico/assert.h \
 lib/chibios//os/various/pico_bindings/dumb/include/pico/version.h \
 lib/pico-sdk/src/common/pico_base/include/pico/config.h \
 lib/chibios//os/various/pico_bindings/dumb/include/pico/config_autogen.h \
 lib/pico-sdk/src/boards/include/boards/pico.h \
 lib/pico-sdk/src/rp2_common/pico_platform/include/pico/platform.h \
 lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/platform_defs.h \
 lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/addressmap.h \
 lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/sio.h \
 lib/pico-sdk/src/common/pico_base/include/pico/types.h \
 lib/pico-sdk/src/common/pico_base/include/pico/error.h \
 quantum/process_keycode/process_key_override.h

keyboards/ymkn/slab40/config.h:

.build/obj_ymkn_slab40_vial/src/info_config.h:

keyboards/ymkn/slab40/keymaps/vial/config.h:

platforms/chibios/config.h:

quantum/keymap_common.h:

quantum/keyboard.h:

platforms/timer.h:

platforms/chibios/_timer.h:

quantum/keymap_introspection.h:

tmk_core/protocol/report.h:

quantum/keycode.h:

quantum/keycodes.h:

quantum/modifiers.h:

quantum/util.h:

quantum/bits.h:

quantum/bitwise.h:

platforms/chibios/_util.h:

quantum/action_layer.h:

quantum/action.h:

platforms/progmem.h:

quantum/action_code.h:

quantum/logging/debug.h:

quantum/logging/print.h:

quantum/logging/sendchar.h:

quantum/keycode_config.h:

quantum/compiler_support.h:

quantum/eeconfig.h:

quantum/quantum_keycodes.h:

quantum/keymap_extras/keymap_us.h:

quantum/sequencer/sequencer.h:

quantum/quantum_keycodes_legacy.h:

quantum/vial.h:

platforms/eeprom.h:

quantum/wear_leveling/wear_leveling_drivers.h:

platforms/chibios/drivers/wear_leveling/wear_leveling_rp2040_flash_config.h:

lib/pico-sdk/src/rp2_common/hardware_flash/include/hardware/flash.h:

lib/pico-sdk/src/common/pico_base/include/pico.h:

lib/pico-sdk/src/common/pico_base/include/pico/types.h:

lib/pico-sdk/src/common/pico_base/include/pico/assert.h:

lib/chibios//os/various/pico_bindings/dumb/include/pico/version.h:

lib/pico-sdk/src/common/pico_base/include/pico/config.h:

lib/chibios//os/various/pico_bindings/dumb/include/pico/config_autogen.h:

lib/pico-sdk/src/boards/include/boards/pico.h:

lib/pico-sdk/src/rp2_common/pico_platform/include/pico/platform.h:

lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/platform_defs.h:

lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/addressmap.h:

lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/sio.h:

lib/pico-sdk/src/common/pico_base/include/pico/types.h:

lib/pico-sdk/src/common/pico_base/include/pico/error.h:

quantum/process_keycode/process_key_override.h:
