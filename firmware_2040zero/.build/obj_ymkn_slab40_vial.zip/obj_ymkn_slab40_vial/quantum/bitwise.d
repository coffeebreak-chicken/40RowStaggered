.build/obj_ymkn_slab40_vial/quantum/bitwise.o: quantum/bitwise.c \
 keyboards/ymkn/slab40/config.h \
 .build/obj_ymkn_slab40_vial/src/info_config.h \
 keyboards/ymkn/slab40/keymaps/vial/config.h platforms/chibios/config.h \
 quantum/util.h quantum/bits.h quantum/bitwise.h \
 platforms/chibios/_util.h

keyboards/ymkn/slab40/config.h:

.build/obj_ymkn_slab40_vial/src/info_config.h:

keyboards/ymkn/slab40/keymaps/vial/config.h:

platforms/chibios/config.h:

quantum/util.h:

quantum/bits.h:

quantum/bitwise.h:

platforms/chibios/_util.h:
