.build/obj_ymkn_slab40_vial/quantum/repeat_key.o: quantum/repeat_key.c \
 keyboards/ymkn/slab40/config.h \
 .build/obj_ymkn_slab40_vial/src/info_config.h \
 keyboards/ymkn/slab40/keymaps/vial/config.h platforms/chibios/config.h \
 quantum/repeat_key.h quantum/action.h platforms/progmem.h \
 quantum/keyboard.h platforms/timer.h platforms/chibios/_timer.h \
 quantum/keycode.h quantum/keycodes.h quantum/modifiers.h \
 quantum/action_code.h quantum/quantum_keycodes.h \
 quantum/keymap_extras/keymap_us.h quantum/sequencer/sequencer.h \
 quantum/quantum_keycodes_legacy.h

keyboards/ymkn/slab40/config.h:

.build/obj_ymkn_slab40_vial/src/info_config.h:

keyboards/ymkn/slab40/keymaps/vial/config.h:

platforms/chibios/config.h:

quantum/repeat_key.h:

quantum/action.h:

platforms/progmem.h:

quantum/keyboard.h:

platforms/timer.h:

platforms/chibios/_timer.h:

quantum/keycode.h:

quantum/keycodes.h:

quantum/modifiers.h:

quantum/action_code.h:

quantum/quantum_keycodes.h:

quantum/keymap_extras/keymap_us.h:

quantum/sequencer/sequencer.h:

quantum/quantum_keycodes_legacy.h:
