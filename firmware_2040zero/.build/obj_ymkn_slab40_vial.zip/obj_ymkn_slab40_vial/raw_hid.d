.build/obj_ymkn_slab40_vial/raw_hid.o: quantum/raw_hid.c \
 keyboards/ymkn/slab40/config.h \
 .build/obj_ymkn_slab40_vial/src/info_config.h \
 keyboards/ymkn/slab40/keymaps/vial/config.h platforms/chibios/config.h \
 quantum/raw_hid.h tmk_core/protocol/host.h tmk_core/protocol/report.h \
 quantum/keycode.h quantum/keycodes.h quantum/modifiers.h quantum/util.h \
 quantum/bits.h quantum/bitwise.h platforms/chibios/_util.h \
 tmk_core/protocol/host_driver.h quantum/led.h

keyboards/ymkn/slab40/config.h:

.build/obj_ymkn_slab40_vial/src/info_config.h:

keyboards/ymkn/slab40/keymaps/vial/config.h:

platforms/chibios/config.h:

quantum/raw_hid.h:

tmk_core/protocol/host.h:

tmk_core/protocol/report.h:

quantum/keycode.h:

quantum/keycodes.h:

quantum/modifiers.h:

quantum/util.h:

quantum/bits.h:

quantum/bitwise.h:

platforms/chibios/_util.h:

tmk_core/protocol/host_driver.h:

quantum/led.h:
