.build/obj_ymkn_slab40_vial/protocol/host.o: tmk_core/protocol/host.c \
 keyboards/ymkn/slab40/config.h \
 .build/obj_ymkn_slab40_vial/src/info_config.h \
 keyboards/ymkn/slab40/keymaps/vial/config.h platforms/chibios/config.h \
 quantum/keyboard.h platforms/timer.h platforms/chibios/_timer.h \
 quantum/keycode.h quantum/keycodes.h quantum/modifiers.h \
 tmk_core/protocol/host.h tmk_core/protocol/report.h quantum/util.h \
 quantum/bits.h quantum/bitwise.h platforms/chibios/_util.h \
 tmk_core/protocol/host_driver.h quantum/led.h quantum/logging/debug.h \
 quantum/logging/print.h quantum/logging/sendchar.h platforms/progmem.h \
 tmk_core/protocol/usb_device_state.h quantum/keycode_config.h \
 quantum/compiler_support.h quantum/eeconfig.h quantum/action_layer.h \
 quantum/action.h quantum/action_code.h

keyboards/ymkn/slab40/config.h:

.build/obj_ymkn_slab40_vial/src/info_config.h:

keyboards/ymkn/slab40/keymaps/vial/config.h:

platforms/chibios/config.h:

quantum/keyboard.h:

platforms/timer.h:

platforms/chibios/_timer.h:

quantum/keycode.h:

quantum/keycodes.h:

quantum/modifiers.h:

tmk_core/protocol/host.h:

tmk_core/protocol/report.h:

quantum/util.h:

quantum/bits.h:

quantum/bitwise.h:

platforms/chibios/_util.h:

tmk_core/protocol/host_driver.h:

quantum/led.h:

quantum/logging/debug.h:

quantum/logging/print.h:

quantum/logging/sendchar.h:

platforms/progmem.h:

tmk_core/protocol/usb_device_state.h:

quantum/keycode_config.h:

quantum/compiler_support.h:

quantum/eeconfig.h:

quantum/action_layer.h:

quantum/action.h:

quantum/action_code.h:
