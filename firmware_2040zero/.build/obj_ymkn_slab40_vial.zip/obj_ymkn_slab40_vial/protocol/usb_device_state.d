.build/obj_ymkn_slab40_vial/protocol/usb_device_state.o: \
 tmk_core/protocol/usb_device_state.c keyboards/ymkn/slab40/config.h \
 .build/obj_ymkn_slab40_vial/src/info_config.h \
 keyboards/ymkn/slab40/keymaps/vial/config.h platforms/chibios/config.h \
 tmk_core/protocol/usb_device_state.h

keyboards/ymkn/slab40/config.h:

.build/obj_ymkn_slab40_vial/src/info_config.h:

keyboards/ymkn/slab40/keymaps/vial/config.h:

platforms/chibios/config.h:

tmk_core/protocol/usb_device_state.h:
