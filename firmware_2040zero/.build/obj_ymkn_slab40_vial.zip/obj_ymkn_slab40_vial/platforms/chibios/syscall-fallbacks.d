.build/obj_ymkn_slab40_vial/platforms/chibios/syscall-fallbacks.o: \
 platforms/chibios/syscall-fallbacks.c keyboards/ymkn/slab40/config.h \
 .build/obj_ymkn_slab40_vial/src/info_config.h \
 keyboards/ymkn/slab40/keymaps/vial/config.h platforms/chibios/config.h \
 platforms/chibios/errno.h

keyboards/ymkn/slab40/config.h:

.build/obj_ymkn_slab40_vial/src/info_config.h:

keyboards/ymkn/slab40/keymaps/vial/config.h:

platforms/chibios/config.h:

platforms/chibios/errno.h:
